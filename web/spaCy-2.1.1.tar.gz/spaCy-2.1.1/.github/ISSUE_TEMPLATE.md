<!--- Please provide a summary in the title and describe your issue here.
Is this a bug or feature request? If a bug, include all the steps that led to the issue.

If you're looking for help with your code, consider posting a question on Stack Overflow instead:
http://stackoverflow.com/questions/tagged/spacy -->



## Your Environment
<!-- Include details of your environment. If you're using spaCy 1.7+, you can also type 
`python -m spacy info --markdown` and copy-paste the result here.-->
* Operating System: 
* Python Version Used: 
* spaCy Version Used: 
* Environment Information: 
