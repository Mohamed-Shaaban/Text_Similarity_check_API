# coding: utf8
from __future__ import unicode_literals


DETS_IRREG = {
    "του": ("το",),
    "των": ("το",),
    "τους": ("το",),
    "τις": ("τη",),
    "τα": ("το",),
    "οι": ("ο", "η"),
}
