# encoding: utf8
from __future__ import unicode_literals


STOP_WORDS = set(
    """
alle allerede alt and andre annen annet at av

bak bare bedre beste blant ble bli blir blitt bris by både

da dag de del dem den denne der dermed det dette disse drept du

eller en enn er et ett etter

fem fikk fire fjor flere folk for fortsatt fotball fra fram frankrike fredag
funnet få får fått før først første

gang gi gikk gjennom gjorde gjort gjør gjøre god godt grunn gå går

ha hadde ham han hans har hele helt henne hennes her hun hva hvor hvordan
hvorfor

i ifølge igjen ikke ingen inn

ja jeg

kamp kampen kan kl klart kom komme kommer kontakt kort kroner kunne kveld
kvinner

la laget land landet langt leder ligger like litt løpet lørdag

man mandag mange mannen mars med meg mellom men mener menn mennesker mens mer
millioner minutter mot msci mye må mål måtte

ned neste noe noen nok norge norsk norske ntb ny nye nå når

og også om onsdag opp opplyser oslo oss over

personer plass poeng politidistrikt politiet president prosent på

regjeringen runde rundt russland

sa saken samme sammen samtidig satt se seg seks selv senere september ser sett
siden sier sin sine siste sitt skal skriver skulle slik som sted stedet stor
store står sverige svært så søndag

ta tatt tid tidligere til tilbake tillegg tirsdag to tok torsdag tre tror
tyskland

under usa ut uten utenfor

vant var ved veldig vi videre viktig vil ville viser vår være vært

å år

ønsker
""".split()
)
